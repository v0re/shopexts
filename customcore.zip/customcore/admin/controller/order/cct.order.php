<?php

	class cct_order extends ctl_order
	{
		var $db;
		function exportXls()
		{
			$io = 'xls';
			$objectName = 'order';
			$this->db = $this->system->database();
			$dataio = $this->system->loadModel('system/dataio');
			$sSql = "SELECT A.order_id,B.bn,B.name,B.price,B.nums,B.amount,from_unixtime(A.createtime),from_unixtime(A.acttime),
						A.total_amount,A.ship_name,A.ship_tel,A.ship_area,A.ship_addr,C.zip,A.mark_text,A.shipping,
						A.cost_freight,D.custom_name,C.uname,A.pay_status,A.ship_status
					FROM sdb_orders AS A, sdb_order_items AS B, sdb_members AS C, sdb_payment_cfg AS D
					WHERE A.order_id = B.order_id AND C.member_id = A.member_id	AND D.id = A.payment
							AND A.disabled = 'false' AND D.disabled = 'false' AND C.disabled = 'false'";

			$aData = $this->db->select($sSql);
			foreach ($aData as &$var)
			{
				$i = $var['pay_status'];
				switch ($i)
				{
					case 0:
						unset($i);
						$var['pay_status'] = '未支付';
						break;
					case 1:
						unset($i);
						$var['pay_status'] = '已支付';
						break;
					case 2:
						unset($i);
						$var['pay_status'] = '处理中';
						break;
					case 3:
						unset($i);
						$var['pay_status'] = '部分付款';
						break;
					case 4:
						unset($i);
						$var['pay_status'] = '部分退款';
						break;
					case 5:
						unset($i);
						$var['pay_status'] = '全额退款';
						break;
				}

				$k = $var['ship_status'];
				switch ($k)
				{
					case 0:
						unset($k);
						$var['ship_status'] = '未发货';
						break;
					case 1:
						unset($k);
						$var['ship_status'] = '已发货';
						break;
					case 2:
						unset($k);
						$var['ship_status'] = '部分发货';
						break;
					case 3:
						unset($k);
						$var['ship_status'] = '部分退货';
						break;
					case 4:
						unset($k);
						$var['ship_status'] = '已退货';
						break;
				}
			}
			$count = count($aData);
			$aInfo = array(
				'订单号'=>'order_id',
				'商品货号'=>'bn',
				'商品名称'=>'name',
				'单价'=>'price',
				'数量'=>'nums',
				'商品总价'=>'amount',
				'下单日期'=>'createtime',
				'最后更新'=>'acttime',
				//'订单总额'=>'total_amount',
				'收货人'=>'ship_name',
				'收货人电话'=>'ship_tel',
				'收货地区'=>'ship_area',
				'收货地址'=>'ship_addr',
				'邮编'=>'zip',
				'订单备注'=>'mark_text',
				//'出库时间'=>'',
				'配送方式'=>'shipping',
				'配送费用'=>'cost_freight',
				'支付方式'=>'payment',
				'会员用户名'=>'uname',
				'付款状态'=>'pay_status',
				'发货状态'=>'ship_status'
				//'货款是否到帐'=>''
			);
			$headCols = array();
			foreach ($aInfo as $key => $var)
			{
				$headCols[] = $key.'('.$var.')';
			}
			$dataio->export_begin($io,$headCols,$objectName,$count);
			$dataio->export_rows($io,$aData);
			$dataio->export_finish($io);
		}
	}
?>