<?php

	$cusmenu['order'] = array(
	    'items'=>array(
            array(
                'type'=>'group',
                'label'=>'订单管理',
                'items'=>array(
                    array(
                    'type'=>'menu',
                    'label'=>'下载订单Excel',
                    'link'=>'index.php?ctl=order/order&act=exportXls'
                    )
                )
            )
		)
	);
?>